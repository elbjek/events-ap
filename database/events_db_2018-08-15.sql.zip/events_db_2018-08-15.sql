# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.22)
# Database: events_db
# Generation Time: 2018-08-14 22:01:52 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table events
# ------------------------------------------------------------

DROP TABLE IF EXISTS `events`;

CREATE TABLE `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `artist` varchar(45) NOT NULL DEFAULT '',
  `image` varchar(355) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `short_desc` varchar(355) DEFAULT NULL,
  `long_desc` text,
  `seatings_id` int(10) unsigned NOT NULL,
  `venues_id` int(10) unsigned NOT NULL,
  `prices_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_events_seatings_idx` (`seatings_id`),
  KEY `fk_events_venues1_idx` (`venues_id`),
  KEY `fk_events_prices1_idx` (`prices_id`),
  CONSTRAINT `fk_events_prices1` FOREIGN KEY (`prices_id`) REFERENCES `prices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_events_seatings` FOREIGN KEY (`seatings_id`) REFERENCES `seatings` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_events_venues1` FOREIGN KEY (`venues_id`) REFERENCES `venues` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;

INSERT INTO `events` (`id`, `artist`, `image`, `city`, `date_time`, `short_desc`, `long_desc`, `seatings_id`, `venues_id`, `prices_id`)
VALUES
	(25,'Isaiah Rashad','images/1534282958_isaiah-rashad.jpg','Dallas,TX','2018-08-15 00:00:39','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nisi lacus, vulputate volutpat turpis dictum, venenatis pharetra sem. Suspendisse laoreet sed nisl eu faucibus','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nisi lacus, vulputate volutpat turpis dictum, venenatis pharetra sem. Suspendisse laoreet sed nisl eu faucibus. Curabitur quis dapibus enim. Nunc convallis velit ut mi lobortis, at pretium urna consequat. Suspendisse tellus orci, tristique non nunc sed, euismod sodales orci. Nam a commodo ipsum. Donec rutrum tortor ut tristique tincidunt. Etiam sagittis vitae est et feugiat.',1,3,1),
	(26,'Isaiah Rashad','images/1534282958_isaiah-rashad.jpg','Dallas,TX','2018-08-15 00:00:40','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nisi lacus, vulputate volutpat turpis dictum, venenatis pharetra sem. Suspendisse laoreet sed nisl eu faucibus','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nisi lacus, vulputate volutpat turpis dictum, venenatis pharetra sem. Suspendisse laoreet sed nisl eu faucibus. Curabitur quis dapibus enim. Nunc convallis velit ut mi lobortis, at pretium urna consequat. Suspendisse tellus orci, tristique non nunc sed, euismod sodales orci. Nam a commodo ipsum. Donec rutrum tortor ut tristique tincidunt. Etiam sagittis vitae est et feugiat.',3,3,2),
	(27,'SZAA','images/1534283609_sza.jpg','Belgrade','2018-08-15 00:00:43','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nisi lacus, vulputate volutpat turpis dictum, venenatis pharetra sem. Suspendisse laoreet sed nisl eu faucibus','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nisi lacus, vulputate volutpat turpis dictum, venenatis pharetra sem. Suspendisse laoreet sed nisl eu faucibus. Curabitur quis dapibus enim. Nunc convallis velit ut mi lobortis, at pretium urna consequat. Suspendisse tellus orci, tristique non nunc sed, euismod sodales orci. Nam a commodo ipsum. Donec rutrum tortor ut tristique tincidunt. Etiam sagittis vitae est et feugiat.',1,1,1),
	(28,'SZAA','images/1534283658_sza.jpg','Belgrade','2018-08-15 00:00:44','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nisi lacus, vulputate volutpat turpis dictum, venenatis pharetra sem. Suspendisse laoreet sed nisl eu faucibus','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nisi lacus, vulputate volutpat turpis dictum, venenatis pharetra sem. Suspendisse laoreet sed nisl eu faucibus. Curabitur quis dapibus enim. Nunc convallis velit ut mi lobortis, at pretium urna consequat. Suspendisse tellus orci, tristique non nunc sed, euismod sodales orci. Nam a commodo ipsum. Donec rutrum tortor ut tristique tincidunt. Etiam sagittis vitae est et feugiat.',2,1,2),
	(29,'Erykah Badu','images/1534283788_erykah.jpg','Dallas,TX','2018-08-16 22:00:00','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nisi lacus, vulputate volutpat turpis dictum, venenatis pharetra sem. Suspendisse laoreet sed nisl eu faucibus','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nisi lacus, vulputate volutpat turpis dictum, venenatis pharetra sem. Suspendisse laoreet sed nisl eu faucibus. Curabitur quis dapibus enim. Nunc convallis velit ut mi lobortis, at pretium urna consequat. Suspendisse tellus orci, tristique non nunc sed, euismod sodales orci. Nam a commodo ipsum. Donec rutrum tortor ut tristique tincidunt. Etiam sagittis vitae est et feugiat.',1,2,1),
	(30,'Erykah Badu','images/1534283836_erykah.jpg','Baltimore, MD','2018-08-14 23:59:34','Lorem ipsum dolor sit amet, consectetur adipiscing elit.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nisi lacus, vulputate volutpat turpis dictum, venenatis pharetra sem. Suspendisse laoreet sed nisl eu faucibus. Curabitur quis dapibus enim. Nunc convallis velit ut mi lobortis, at pretium urna consequat. Suspendisse tellus orci, tristique non nunc sed, euismod sodales orci. Nam a commodo ipsum. Donec rutrum tortor ut tristique tincidunt. Etiam sagittis vitae est et feugiat.',3,2,3);

/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table prices
# ------------------------------------------------------------

DROP TABLE IF EXISTS `prices`;

CREATE TABLE `prices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `price` decimal(7,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

LOCK TABLES `prices` WRITE;
/*!40000 ALTER TABLE `prices` DISABLE KEYS */;

INSERT INTO `prices` (`id`, `price`)
VALUES
	(1,2900.00),
	(2,1500.00),
	(3,800.00),
	(4,1850.00);

/*!40000 ALTER TABLE `prices` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table seatings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `seatings`;

CREATE TABLE `seatings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `seat` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

LOCK TABLES `seatings` WRITE;
/*!40000 ALTER TABLE `seatings` DISABLE KEYS */;

INSERT INTO `seatings` (`id`, `seat`)
VALUES
	(1,'VIP'),
	(2,'Fan Pit'),
	(3,'Parter'),
	(4,'Tribine');

/*!40000 ALTER TABLE `seatings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(125) NOT NULL,
  `email` varchar(350) NOT NULL,
  `password` varchar(55) NOT NULL,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `avatar` varchar(225) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `username`, `email`, `password`, `firstname`, `lastname`, `avatar`)
VALUES
	(2,'elbjek','lenabjekovic@hotmail.com','$1$rasmusle$uwzLzKVWDEpvbNytWXBmS/\n','Lena','Bjekovic','');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table venues
# ------------------------------------------------------------

DROP TABLE IF EXISTS `venues`;

CREATE TABLE `venues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(125) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

LOCK TABLES `venues` WRITE;
/*!40000 ALTER TABLE `venues` DISABLE KEYS */;

INSERT INTO `venues` (`id`, `title`)
VALUES
	(1,'Belgrade Arena'),
	(2,'Staples Center'),
	(3,'Texas Horse Park');

/*!40000 ALTER TABLE `venues` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
